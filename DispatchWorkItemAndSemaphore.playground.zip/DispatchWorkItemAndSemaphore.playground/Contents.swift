import Foundation

class DispatchWorkItemDemo {
    private var newWorkItem: DispatchWorkItem?
    func getAPIsData(query: String) {
        newWorkItem?.cancel()
        let workItem = DispatchWorkItem {
            print("Network Calling goes here for string  \(query)")
        }
        
        newWorkItem = workItem
        
        DispatchQueue.global().asyncAfter(deadline: .now(), execute: newWorkItem!)
        
    }
}


 let obj1 = DispatchWorkItemDemo()
 obj1.getAPIsData(query: "s")
 obj1.getAPIsData(query: "sh")

//Here thread's sleep seconds must be > than asynchAfter() seconds. Otherwise only shore output will be printed everytime.
//i.e we should pass one sec more than the value we pass there

 Thread.sleep(forTimeInterval: 3)
 obj1.getAPIsData(query: "sho")
 obj1.getAPIsData(query: "Shore")

//Output:
//Network Calling goes here for string  sh
//Network Calling goes here for string  Shore

/*MARK: - If we dont specify number of seconds and only call DispatchQueue.global().asyncAfter(deadline: .now(), execute:workItem) then we get below output:
 
 Network Calling goes here for string  s
 Network Calling goes here for string  sh
 Network Calling goes here for string  sho
 Network Calling goes here for string  Shore
 */


class DispatchSemaphoreDemo  {
  func getBillingDetailsOfAllLane()  {

  let queue = DispatchQueue(label: "Concurrent Queue", attributes: .concurrent)

  let semaphore = DispatchSemaphore(value: 1)

  let billingMachine = { (billingAmount: Int, laneNumber: Int) in
      Thread.sleep(forTimeInterval: 4.0)
  print("Billed \(billingAmount) at lane \(laneNumber)")
  }

queue.async {
  print("Lane 1 is scanning customer A product")
  print("Lane 1 on thread\(Thread.current)")

  Thread.sleep(forTimeInterval: 2)
  print("Lane 1 pressed buzzer")

  semaphore.wait()
  billingMachine(1000,1)
  semaphore.signal()
  print("Lane 1 finished billing")
}
queue.async {
  print("Lane 2 is scanning customer A product")
  print("Lane 2 on thread\(Thread.current)")

  Thread.sleep(forTimeInterval: 2)
  print("Lane 2 pressed buzzer")

  semaphore.wait()
  billingMachine(100,2)
  semaphore.signal()
  print("Lane 2 finished billing")
}
queue.async {
  print("Lane 3 is scanning customer A product")
  print("Lane 3 on thread\(Thread.current)")

  Thread.sleep(forTimeInterval: 2)
  print("Lane 3 pressed buzzer")

  semaphore.wait()
  billingMachine(50,3)
  semaphore.signal()
  print("Lane 3 finished billing")
}
}

}

let obj = DispatchSemaphoreDemo()
obj.getBillingDetailsOfAllLane()

//Lane 1 is scanning customer A product
//Lane 3 is scanning customer A product
//Lane 2 is scanning customer A product
//Lane 3 on thread<NSThread: 0x600000841680>{number = 4, name = (null)}
//Lane 2 on thread<NSThread: 0x600000854080>{number = 8, name = (null)}
//Lane 1 on thread<NSThread: 0x600000845dc0>{number = 3, name = (null)}
//Lane 3 pressed buzzer
//Lane 1 pressed buzzer
//Lane 2 pressed buzzer
//Billed 1000 at lane 1
//Lane 1 finished billing
//Billed 100 at lane 2
//Lane 2 finished billing
//Billed 50 at lane 3
//Lane 3 finished billing
